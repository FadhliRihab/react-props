import React from 'react';
import Profile from './profile/Profile'
import './App.css';

function App() {
  return (
    <div>
      <Profile fullName="Rihab Fadhli" bio="welcome" profession="web developer" />
    </div>
  );
}

export default App;
