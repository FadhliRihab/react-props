import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class Profile extends Component{
    render(){
        return(
            <div>
             {this.props.fullName} <br/>
             {this.props.bio} <br/>
             {this.props.profession}
            </div>
        )
    }
}
export default Profile